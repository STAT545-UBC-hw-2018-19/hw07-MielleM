library(testthat)
library(getmode)

test_check("getmode")
